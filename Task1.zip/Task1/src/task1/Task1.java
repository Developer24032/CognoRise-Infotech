package task1;

import java.util.Random;
import java.util.Scanner;

public class Task1 {
	
	public static void guessAgain(int random_number, int guessed_number, int number_of_guesses, Scanner scanner) {
		while(true) {
			if(guessed_number > random_number) {
				System.out.println("TOO HIGH!");
				number_of_guesses++;
				System.out.println("==================================================");
				System.out.print("Enter your guess again (0 - 100): ");
				guessed_number = scanner.nextInt();
			}
			else if(guessed_number < random_number) {
				System.out.println("TOO LOW!");
				number_of_guesses++;
				System.out.println("==================================================");
				System.out.print("Enter your guess again (0 - 100): ");
				guessed_number = scanner.nextInt();
			}
			else {
				System.out.println("CORRECT!");
				System.out.println("Total number of guesses: " + ++number_of_guesses);
				System.out.println("==================================================");
				scanner.close();
				break;
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		Random random = new Random();
		int correct_guess, user_guess, number_of_guesses = 0;
		
		correct_guess = random.nextInt(0, 100);
		System.out.println("==================================================");
		System.out.print("Enter your guess (0 - 100): ");
		user_guess = input.nextInt();
		
		if(user_guess != correct_guess)
			guessAgain(correct_guess, user_guess, number_of_guesses, input);
		else {
			System.out.println("CORRECT!");
			System.out.println("Total number of guesses: " + ++number_of_guesses);
			System.out.println("==================================================");
			input.close();
		}
	}

}
