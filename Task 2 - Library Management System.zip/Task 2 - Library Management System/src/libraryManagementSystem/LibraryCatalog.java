package libraryManagementSystem;

import java.util.ArrayList;

public class LibraryCatalog {
	private ArrayList<Book> books;

    public LibraryCatalog() {
        books = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
        System.out.println("Added: " + book);
    }

    public Book searchByTitle(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null; // Not found
    }

    public Book searchByAuthor(String author) {
        for (Book book : books) {
            if (book.getAuthor().equalsIgnoreCase(author)) {
                return book;
            }
        }
        return null; // Not found
    }

    public void checkOutBook(String title) {
        Book book = searchByTitle(title);
        if (book != null && !book.isCheckedOut()) {
            book.checkOut();
            System.out.println("Checked out: " + book);
        } else if (book != null) {
            System.out.println("The book is already checked out.");
        } else {
            System.out.println("Book not found.");
        }
    }

    public void returnBook(String title) {
        Book book = searchByTitle(title);
        if (book != null && book.isCheckedOut()) {
            book.returnBook();
            System.out.println("Returned: " + book);
        } else if (book != null) {
            System.out.println("The book was not checked out.");
        } else {
            System.out.println("Book not found.");
        }
    }

    public void displayBooks() {
        for (Book book : books) {
            System.out.println(book);
        }
    }
}
