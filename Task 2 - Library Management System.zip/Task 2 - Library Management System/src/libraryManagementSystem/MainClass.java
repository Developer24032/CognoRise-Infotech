package libraryManagementSystem;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LibraryCatalog catalog = new LibraryCatalog();

        // Adding books to the catalog
        catalog.addBook(new Book("The Great Gatsby", "F. Scott Fitzgerald"));
        catalog.addBook(new Book("1984", "George Orwell"));
        catalog.addBook(new Book("To Kill a Mockingbird", "Harper Lee"));

        // Display all books
        System.out.println("\nAll Books:");
        catalog.displayBooks();

        // Check out a book
        System.out.println("\nChecking out '1984':");
        catalog.checkOutBook("1984");

        // Try to check out the same book again
        System.out.println("\nTrying to check out '1984' again:");
        catalog.checkOutBook("1984");

        // Return the book
        System.out.println("\nReturning '1984':");
        catalog.returnBook("1984");

        // Search for a book by title
        System.out.println("\nSearching for 'The Great Gatsby':");
        Book searchedBook = catalog.searchByTitle("The Great Gatsby");
        if (searchedBook != null) {
            System.out.println("Found: " + searchedBook);
        } else {
            System.out.println("Book not found.");
        }

        // Display all books again
        System.out.println("\nAll Books after operations:");
        catalog.displayBooks();
	}

}
