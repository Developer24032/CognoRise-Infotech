package calculator_app;

import java.util.InputMismatchException;
import java.util.Scanner;

public class CalculatorApp {
	
	public static Double calculate(double x, double y, char operator, double result) {
		switch(operator) {
		case '+':
			result = x + y;
			return result;
		case '-':
			result = x - y;
			return result;
		case '*':
			result = x * y;
			return result;
		case '/':
			result = x / y;
			return result;
		default:
			System.out.println("Invalid Operator!");
			return 0.0;
		}
	}

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double first_number, second_number, result = 0.0;
		char operator;
		
		try {
			System.out.print("Enter the first number: ");
			first_number = input.nextDouble();
			
			System.out.print("Emter the second number: ");
			second_number = input.nextDouble();
			
			System.out.print("Choose an operator (+, -, *, /): ");
			operator = input.next().charAt(0);
			
			double final_result = calculate(first_number, second_number, operator, result);
			
			System.out.println("Final Result: " + final_result);
			input.close();
		}
		catch(InputMismatchException e) {
			System.err.println(e + " Please Enter a numerical value");
		}
		catch(ArithmeticException e) {
			System.err.println(e + " Division by zero is not applicable");
		}
	}

}
